# Running this is easy!
 $ python ./toms-diy-store.py

# Support

This program should run on any Python 2.X platform.

# Using in-built test-cases
 $ python ./toms-diy-store.py --test

# Other Important Notes
This documentation was also written in markdown, and you can see it's full
glory by opening README.html in a modern browser.

This file was mostly written in linux, so the EOL (end of line) format may
display incorrectly inside your editor. 
